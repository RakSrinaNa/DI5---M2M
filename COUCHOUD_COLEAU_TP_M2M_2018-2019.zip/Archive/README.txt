codes: contient les codes demandés
	* bme: Utilisation du BME avec la librairie
	* bme-custom: Utilisation du BME sans librairie
	* lcd: Affichage des infos du DHT sur l'écran LCD
	* led: Clignotage de la LED sur la carte
	* led_rgb_pot: Controle de la LED avec un potentiomètre
	* led_rgb_temp: Controle de la LED avec le DHT
	* server: Le verveur avec la librairie BME externe
	* server2: Le serveur avec librarie BME intégrée

libraries: les libraries utilisées

rapport: Le rapport
	* Le PDF
	* La source .tex, non compilable
	* Les images
